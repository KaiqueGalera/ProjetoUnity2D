using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NumberSelector : MonoBehaviour
{
    private List<int> numbers = new List<int> { 1, 2, 3, 4, 5 };
    private List<int> usedNumbers = new List<int>();

    // Método para sortear um número
    public int DrawNumber()
    {
        if (numbers.Count == 0)
        {
            Debug.LogWarning("Não há mais números disponíveis para sortear.");
            return -1; // Ou qualquer outro valor que indique que não há mais números disponíveis
        }

        int index = Random.Range(0, numbers.Count);
        return numbers[index];
    }

    // Método para remover um número sorteado
    public void RemoveNumber(int number)
    {
        if (numbers.Contains(number))
        {
            numbers.Remove(number);
            usedNumbers.Add(number);
        }
        else
        {
            Debug.LogWarning("Número não está disponível para remoção.");
        }
    }

    // Método para resetar a lista de números disponíveis
    public void ResetNumbers()
    {
        numbers = new List<int> { 1, 2, 3, 4, 5 };
        usedNumbers.Clear();
    }
}