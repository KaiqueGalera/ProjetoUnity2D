using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TesteResposta : MonoBehaviour
{
    // Start is called before the first frame update
void Start()
{
    foreach (var r in GerenciamentoResposta.Instance.respostas)
    {
        Debug.Log($"Resposta: {r.textoResposta} | Correta: {r.isCorreta}");
    }
}

}
