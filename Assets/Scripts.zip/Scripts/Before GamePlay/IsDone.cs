using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IsDone : MonoBehaviour
{   
    public  bool    isFadeDone;

    public void     FadeIsDone()
    {
        isFadeDone = true;
    }
}
