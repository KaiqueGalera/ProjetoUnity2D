using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class GameSettings : MonoBehaviour
{
    public DifficultySettings easy   = new DifficultySettings();
    public DifficultySettings normal = new DifficultySettings();
    public DifficultySettings hard   = new DifficultySettings();
    
    public static DifficultySettings currentSettings;

    void Start()
    {
        InitializeDifficultySettings();
    }

    void InitializeDifficultySettings()
    {
        // Definindo os valores para o modo fácil
        easy.playerLives = 4;
        easy.playerAmmShoot = 5;
        easy.platformSpeed = 3.0f;
        normal.playerInveTime = 2.5f;
        easy.bossAttack1   = 25;
        easy.bossAttack2   = 10;
        easy.bossAttack3   = 15;
        easy.bossAttack4   = 10;

        // Definindo os valores para o modo normal
        normal.playerLives = 3;
        normal.playerAmmShoot = 3;
        normal.platformSpeed = 4.0f;
        normal.playerInveTime = 2.5f;
        normal.bossAttack1   = 30;
        normal.bossAttack2   = 10;
        normal.bossAttack3   = 20;
        normal.bossAttack4   = 15;

        // Definindo os valores para o modo difícil
        hard.playerLives = 2;
        hard.playerAmmShoot = 0;
        hard.platformSpeed = 5.0f;
        hard.playerInveTime = 2.0f;
        hard.bossAttack1   = 50;
        hard.bossAttack2   = 20;
        hard.bossAttack3   = 40;
        hard.bossAttack4   = 30;

    }

    public void SetDifficulty(string difficulty)
    {
        switch (difficulty)
        {
            case "Easy":
                currentSettings = easy;
                break;
            case "Normal":
                currentSettings = normal;
                break;
            case "Hard":
                currentSettings = hard;
                break;
        }
    }
}