using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InteractableObject : MonoBehaviour
{
    // Dicas de como organizar e usar os índices
    // 0 -- Porta
    // 1 -- NPC
    // 2 -- Boss 

    public          int         idInteractiveObj;

}
