using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class GerenciadorCreditosLoopcopy : MonoBehaviour
{
    public GameObject prefabResposta;
    public Transform pontoAparecer;
    public Transform pontoSumir;
    public Transform contentContainer;
    public float velocidade = 30f;
    public float espacamento = 100f;

    private List<GameObject> respostasInstanciadas = new List<GameObject>();

    void Start()
    {
        float yInicial = pontoAparecer.transform.position.y;

        foreach (var resposta in GerenciamentoResposta.Instance.respostas)
        {
            GameObject novaResposta = CriarItem(resposta.textoResposta, resposta.isCorreta);
            respostasInstanciadas.Add(novaResposta);
            
            // Posiciona cada nova resposta com espaçamento vertical
            novaResposta.transform.position = new Vector3(pontoAparecer.position.x, yInicial, pontoAparecer.position.z);

            yInicial -= espacamento; // Aplica o espaçamento entre as respostas
            respostasInstanciadas.Add(novaResposta);
        }
    }

    void Update()
    {
        foreach (GameObject resposta in respostasInstanciadas)
        {
            resposta.transform.Translate(Vector3.up * velocidade * Time.deltaTime);

            if (resposta.transform.position.y > pontoSumir.position.y)
            {
                resposta.transform.position = new Vector3(
                    pontoAparecer.position.x,
                    pontoAparecer.position.y,
                    resposta.transform.position.z
                );
            }
        }
    }

    GameObject CriarItem(string texto, bool correto)
    {
        GameObject novo = Instantiate(prefabResposta, contentContainer);
        novo.transform.position = pontoAparecer.position;

        var textoUI = novo.GetComponentInChildren<TextMeshProUGUI>();
        textoUI.text = texto;
        textoUI.color = correto ? Color.green : Color.red;
        textoUI.fontSize = 36;
        textoUI.alignment = TextAlignmentOptions.Center;

        return novo;
    }
}
