// using System.Collections;
// using System.Collections.Generic;
// using UnityEngine;

// public class Boss_Run : StateMachineBehaviour
// {
//     Transform           playerTr;
//     Rigidbody2D         bossRb;
//     BossController      _BossController;
//     HeroController      _HeroController;
//     // OnStateEnter is called when a transition starts and the state machine starts to evaluate this state
//     override public void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
//     {
//        playerTr        = GameObject.FindGameObjectWithTag("Player").transform;
//        bossRb          = animator.GetComponent<Rigidbody2D>();
//        _HeroController = FindAnyObjectByType(typeof(HeroController)) as HeroController;
//        _BossController = animator.GetComponent<BossController>();
//     }

//     // OnStateUpdate is called on each Update frame between OnStateEnter and OnStateExit callbacks
//     override public void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
//     {
//         float direction = playerTr.position.x - animator.transform.position.x;
//         _BossController.Flip(direction);

//         Vector2 target = new Vector2(playerTr.position.x, bossRb.position.y);

//         Vector2 newPos = Vector2.MoveTowards(bossRb.position, target, _BossController.moveSpeed * Time.fixedDeltaTime);

//         bossRb.MovePosition(newPos);

//         if (Vector2.Distance(playerTr.position, bossRb.position) > _BossController.rangeDistance && !_BossController.isRangeAttack)
//         {
//             animator.SetTrigger("Attack3");

//             _BossController.isRangeAttack = true;

//             Debug.Log("Tiro");
//         } 
//         else if (Vector2.Distance(playerTr.position, bossRb.position) <= _BossController.stopDistance && !_BossController.isAttack1) 
//         {
//             animator.SetTrigger("Attack2");

//             _BossController.JumpAwayFromPlayer();

//             _BossController.isRangeAttack = false;
//         }
//     }

//     // OnStateExit is called when a transition ends and the state machine finishes evaluating this state
//     override public void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
//     {
//        animator.ResetTrigger("Attack2");
//     }

// }
