using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyLifeControl : MonoBehaviour
{
    private  GameController      _GameController;
    public   string              enemyName;

    [Header("Controle de dano dado")]
    // public   int                 flyMachineDmg;
    
    [Header("Controle de dano recebido")]
    public   int                 lifeMax;
    

    // Start is called before the first frame update
    void Start()
    {
        _GameController =    FindAnyObjectByType(typeof(GameController)) as GameController;
    }


    // private void OnTriggerEnter2D(Collider2D other) 
    // {
    //     // switch(other.gameObject.tag)
    //     // {
    //     //     // case "heroDmg":
                
    //     //     //     //GameObject temp = Instantiate(_GameController.hitPrefab, transform.position, transform.localRotation); // Instancia animação (tem q estar prefab) no local do enimigo
                
    //     //     //     DamageController(_GameController.danoEspada); // Acessa ao GameController para fornecer o atributo dano da arma (no caso a espada) para a função DanoController
    //     //     //     print("tomei dano");
    //     //     //     return;

    //     // }
    // }

    // void DamageController(int dmg)
    // {
    //     lifeMax -= dmg;

    //     if(lifeMax <= 0)
    //     {   
    //         Destroy(this.gameObject);
    //     }
    // }
}
