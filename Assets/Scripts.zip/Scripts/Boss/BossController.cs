    using System.Collections;
using UnityEngine;

public class BossController : MonoBehaviour
{
    [Header("Colisores")]
    public Collider2D       attackPuch;
    public Collider2D       attackKick;
    public Collider2D       attackLaser;
    public Collider2D       mainCollider;

    [Header("Animação")]
    public Animator         animator;

    [Header("Invulnerabilidade")]
    public SpriteRenderer   bossSr;
    public bool             isInvulnerable = false;
    public float            invulnerableDuration = 2.0f; // Duração da invulnerabilidade após sofrer dano
    public Color            invencibleColor;
    public float            blinkTime = 0.1f;

    [Header("Movimentação")]
    public bool             isBossActived;
    public Transform        player; // Referência ao jogador
    public float            moveSpeed = 2.0f; // Velocidade de movimento
    public bool             isFacingRight = true;

    [Header("Ataques")]
    public bool             isAttacking = false;

    [Header("Ataques Distância")]
    public float            rangeDistance; // Distância mínima para parar e atacar a distância
    public bool             isRangeAttack  = false;

    [Header("Spawn enemies")]
    public GameObject       enemyPrefab; // Prefab dos inimigos que serão spawnados no attack4
    public Transform[]      spawnPoints; // Pontos onde os inimigos serão spawnados
    public float            stopDistance; // Distância mínima para parar e atacar

    [Header("Jump")]
    public float            jumpDistance;
    private Rigidbody2D     bossRb;
    public float            jumpForce;
    public bool             isJumping = false;

    [Header("Life")]
    public int              maxHealth = 100; // Vida máxima do boss
    private int             currentHealth;



    private void Start()
    {
        bossRb   = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        
        // Desativar colisores de ataque no início
        attackPuch.enabled  = false;
        attackKick.enabled  = false;
        attackLaser.enabled = false;
        
        currentHealth = maxHealth;
    }

    void Update()
    {
        if (isJumping || isAttacking)
            return;
        
        
        float distanceToPlayer = Vector2.Distance(transform.position, player.position);

        if ((distanceToPlayer > stopDistance) && isBossActived == true)
        {
            MoveTowardsPlayer();
        }
        else if (isBossActived == true)
        {
            StartCoroutine("PerformAttackSequence");
        }

        if (currentHealth <= maxHealth / 2)
        {
            SpawnEnemies();
        }
    }    
    
    private void OnDrawGizmosSelectd()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, stopDistance);
    }
    
    void MoveTowardsPlayer()
    {
        animator.SetBool("isWalking", true);
        Vector2 targetPosition = new Vector2(player.position.x, transform.position.y);
        transform.position = Vector2.MoveTowards(transform.position, targetPosition, moveSpeed * Time.deltaTime);
        
        if ((player.position.x > transform.position.x && isFacingRight) || (player.position.x < transform.position.x && !isFacingRight))
        {
            Flip();
        }
    }
    
    IEnumerator PerformAttackSequence()
    {
        isAttacking = true;
        MoveTowardsPlayer(); // Ensure boss is facing the player correctly before attacking

        Attack1();
        yield return new WaitForSeconds(1f); // Adjust the delay as needed

        Flip();
        // JumpAway();
        animator.SetTrigger("Jump");
        yield return new WaitForSeconds(2f); // Adjust the delay as needed

        Attack2();
        yield return new WaitForSeconds(1f); // Adjust the delay as needed

        isAttacking = false;
    }    
    
    void Attack1()
    {
        animator.SetTrigger("Attack1");
    }

    void JumpAway()
    {
        isJumping = true;
        Vector2 jumpDirection = isFacingRight ? Vector2.left : Vector2.right;
        bossRb.velocity = new Vector2(0, 0); // Reset current velocity to prevent stacking with other forces
        bossRb.AddForce(jumpDirection * jumpDistance + Vector2.up * jumpForce, ForceMode2D.Impulse);
        Invoke(nameof(EndJump), 1f); // Adjust the delay as needed    
    }

    void EndJump()
    {
        isJumping = false;
    }

    void Attack2()
    {
        Flip();
        animator.SetTrigger("Attack2");
        // Add code for ranged attack
        // Invoke(nameof(ResumeMovement), 1f); // Adjust the delay as needed
    }
    

    public void TakeDamage(int damage)
    {
        if (isInvulnerable) return;
        
        currentHealth -= damage;

        if (currentHealth <= 0)
        {
            Die();
        }
        else
        {
            StartCoroutine("BeInvencible");
        }
    }
    
    public IEnumerator BeInvencible() // método assincrono para ativar invencibilidade (conj. de caracteristicas) do personagem durante determinado tempo (invulTime)
    {   
        isInvulnerable = true;

        bossSr.color = invencibleColor; // Cor translúcida (0,0,0,30)
        
        StartCoroutine("BlinkInvencible");

        yield return new WaitForSeconds(invulnerableDuration);

        bossSr.color = Color.white;

        isInvulnerable = false;

        bossSr.enabled = true;

        StopCoroutine("BlinkInvencible");
        
    }

    public IEnumerator BlinkInvencible() // método assincrono para piscar a imagem do personagem desativando e ativando sua sprite durante determinado tempo (blinkTime)
    {
        
        yield return new WaitForSeconds(blinkTime);

        bossSr.enabled = !bossSr.enabled;
            
        StartCoroutine("BlinkInvencible");

    }

    void Flip()
    {
        isFacingRight = !isFacingRight;
        Vector3 localScale = transform.localScale;
        localScale.x *= -1;
        transform.localScale = localScale;
    }
    
    private void Die()
    {
        // Destruir o boss ou realizar alguma animação de morte
        Destroy(gameObject);
    }
    
    // public void JumpAwayFromPlayer()
    // {
    //     Vector2 jumpDirection = (transform.position.x > player.position.x) ? Vector2.right : Vector2.left;
    //     bossRb.AddForce(new Vector2(jumpDirection.x * jumpDistance, jumpForce), ForceMode2D.Impulse);
    //     Debug.Log("Pulo");
    // }
    
    // Métodos chamados pela animação via Animation Events
    public void EnableAttackPuch()
    {
        attackPuch.enabled = true;
    }

    public void DisableaPuch()
    {
        attackPuch.enabled = false;
    }

    public void EnableAttackKick()
    {
        attackKick.enabled = true;
    }

    public void DisableAttackKick()
    {
        attackKick.enabled = false;
    }

    public void EnableAttackLaser()
    {
        attackLaser.enabled = true;
    }

    public void DisableAttackLaser()
    {
        attackLaser.enabled = false;
    }

    public void SpawnEnemies()
    {
        animator.SetTrigger("isAttacking3");

        foreach (var spawnPoint in spawnPoints)
        {
            Instantiate(enemyPrefab, spawnPoint.position, Quaternion.identity);
        }
    }
}